$(function(){
    
    $('.carousel').carousel({
        
        interval: 3000, 
        pause:"null",
        wrap: true
    });
    
    
    
});